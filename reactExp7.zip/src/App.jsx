import React from 'react'
import LandingPage from './pages/LandingPage'
import './App.css'

const App = () => {
  return (
    <>
      <LandingPage></LandingPage>
    </>
  )
}

export default App